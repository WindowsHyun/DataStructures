#ifndef _ATTACK_2_H_
#define _ATTACK_2_H_

#include <stdio.h>

void WhiteAttack_2012180004( int *x, int *y );
void WhiteDefence_2012180004( int x, int y );

#endif
