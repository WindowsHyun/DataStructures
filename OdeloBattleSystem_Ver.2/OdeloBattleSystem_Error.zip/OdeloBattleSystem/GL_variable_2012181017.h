#pragma once

#include <stdio.h>

#define B_SIZE_2012181017 8
#define NONE_STONE_2012181017 0
#define WHITE_STONE_2012181017 2
#define BLACK_STONE_2012181017 1

#define BLACK_TURN_MIN_2012181017 18
#define WHITE_TURN_MIN_2012181017 10


typedef struct _boardStone{
	int x, y;
	bool checkFlag;
}STONE_2012181017;


void checkMaxTurnStone_2012181017(int userStone, STONE_2012181017& result);

void	changeStone_2012181017(int x, int y, int userStone);
bool	changeStone_2012181017(int x, int y, int userStone, int tX, int tY);