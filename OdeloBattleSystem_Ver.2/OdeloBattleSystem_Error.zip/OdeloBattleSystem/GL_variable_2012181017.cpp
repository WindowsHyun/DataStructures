#include "GL_variable_2012181017.h"


int	board_2012181017[B_SIZE_2012181017][B_SIZE_2012181017] = {{NONE_STONE_2012181017},
										{NONE_STONE_2012181017},
										{NONE_STONE_2012181017},
										{0, 0, 0, BLACK_STONE_2012181017, WHITE_STONE_2012181017, 0, 0, 0},
										{0, 0, 0, WHITE_STONE_2012181017, BLACK_STONE_2012181017, 0, 0, 0},
										{NONE_STONE_2012181017},
										{NONE_STONE_2012181017},
										{NONE_STONE_2012181017}};

STONE_2012181017 checkPen_2012181017 = {0};


void checkMaxTurnStone_2012181017(int userStone, STONE_2012181017& result){
	static	int	turnCount = 0;
	int maxTurn = 0;
	int minTurn = 0xfffffff;

	int x, y;
	/*for(int tmpI=0; tmpI<B_SIZE_2012181017; ++tmpI){
		for(int tmpJ = B_SIZE_2012181017-1; 0 <= tmpJ; --tmpJ){*/
	if(BLACK_STONE_2012181017 == userStone){
		for(int tmpI=0; tmpI<B_SIZE_2012181017; ++tmpI){
			for(int tmpJ = 0; tmpJ<B_SIZE_2012181017; ++tmpJ){
				for(int i=-1; i<2; ++i){
					for(int j=-1; j<2; ++j){
						x = tmpJ + j;
						y = tmpI + i;
						int tmpMax = 0;

						if(board_2012181017[tmpI][tmpJ] == NONE_STONE_2012181017){
							while((board_2012181017[y][x] != userStone && board_2012181017[y][x] != NONE_STONE_2012181017)&& (0<=x && x<B_SIZE_2012181017) && (0<=y && y<B_SIZE_2012181017)){
								x += j;
								y += i;
								tmpMax++;
							}

							if(board_2012181017[y][x] == userStone){
								if(turnCount < BLACK_TURN_MIN_2012181017){
									if(tmpMax != 0 && tmpMax < minTurn){
										minTurn = tmpMax;
										result.x = tmpJ;
										result.y = tmpI;
										result.checkFlag = true;
									}
								}else{
									if(maxTurn < tmpMax){
										maxTurn = tmpMax;
										result.x = tmpJ;
										result.y = tmpI;
										result.checkFlag = true;
									}
								}
							}
						}else{
							i = 3;
							j = 3;
						}
					}
				}
			}
		}
	}else if(userStone == WHITE_STONE_2012181017){
		for(int tmpI=0; tmpI<B_SIZE_2012181017; ++tmpI){
			for(int tmpJ = B_SIZE_2012181017-1; 0 <= tmpJ; --tmpJ){
				for(int i=-1; i<2; ++i){
					for(int j=-1; j<2; ++j){
						x = tmpJ + j;
						y = tmpI + i;
						int tmpMax = 0;

						if(board_2012181017[tmpI][tmpJ] == NONE_STONE_2012181017){
							while((board_2012181017[y][x] != userStone && board_2012181017[y][x] != NONE_STONE_2012181017)&& (0<=x && x<B_SIZE_2012181017) && (0<=y && y<B_SIZE_2012181017)){
								x += j;
								y += i;
								tmpMax++;
							}

							if(board_2012181017[y][x] == userStone){
								if(turnCount < WHITE_TURN_MIN_2012181017){
									if(tmpMax != 0 && tmpMax < minTurn){
										minTurn = tmpMax;
										result.x = tmpJ;
										result.y = tmpI;
										result.checkFlag = true;
									}
								}else{
									if(maxTurn < tmpMax){
										maxTurn = tmpMax;
										result.x = tmpJ;
										result.y = tmpI;
										result.checkFlag = true;
									}
								}
							}
						}else{
							i = 3;
							j = 3;
						}
					}
				}
			}
		}
	}

	turnCount++;
}

void	changeStone_2012181017(int x, int y, int userStone){
	int tmpX = x, tmpY = y;
	if(board_2012181017[y][x] == NONE_STONE_2012181017){

		for(int i=-1; i<2; ++i){
			for(int j=-1; j<2; ++j){
				board_2012181017[y][x] = userStone;
				changeStone_2012181017(x+j, y+i, userStone, j, i);
			}
		}
	}



	/*for(int i=0; i<B_SIZE_2012181017; ++i){
		for(int j=0; j<B_SIZE_2012181017; ++j){
			if(NONE_STONE_2012181017 == board_2012181017[i][j]){
				printf("  ");
			}else if(BLACK_STONE_2012181017 == board_2012181017[i][j]){
				printf("��");
			}else{
				printf("��");
			}
		}
		printf("\n");
	}*/
}

bool	changeStone_2012181017(int x, int y, int userStone, int tX, int tY){
	if(x < 0 || B_SIZE_2012181017 == x || y < 0 || B_SIZE_2012181017 == y)
		return false;
	if(board_2012181017[y][x] == userStone){
		return true;
	}else if(board_2012181017[y][x] == userStone%2+1){
		if(changeStone_2012181017(x+tX, y+tY, userStone, tX, tY)){
			board_2012181017[y][x] = userStone;
			return true;
		}
	}else{
		return false;
	}
	return false;
}