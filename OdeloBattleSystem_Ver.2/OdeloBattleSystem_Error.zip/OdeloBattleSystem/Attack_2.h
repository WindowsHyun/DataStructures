//#ifndef _ATTACK_2_H_
//#define _ATTACK_2_H_
//
//#include <stdio.h>
//
////void WhiteAttack_2012180004( int *x, int *y );
////void WhiteDefence_2012180004( int x, int y );
//
//_201218101
//
////void WhiteAttack( int *x, int *y );
////void WhiteDefence( int x, int y );
//
//
//#endif



#ifndef _ATTACK_2_H_
#define _ATTACK_2_H_

#include "GL_variable_2012181017.h"

void WhiteAttack_2012181017( int *x, int *y )
{
	STONE_2012181017 whiteAttack = {0};
	checkMaxTurnStone_2012181017(WHITE_STONE_2012181017, whiteAttack);
	if(whiteAttack.checkFlag){
		*x = whiteAttack.x;
		*y = whiteAttack.y;
	}else{
		//*x = 0;
		//*y = 0;
	}
	changeStone_2012181017(*x, *y, WHITE_STONE_2012181017);
}

void WhiteDefence_2012181017( int x, int y )
{
	changeStone_2012181017(x, y, BLACK_STONE_2012181017);
}

void WhiteAttack_2012180004( int *x, int *y );
void WhiteDefence_2012180004( int x, int y );
#endif