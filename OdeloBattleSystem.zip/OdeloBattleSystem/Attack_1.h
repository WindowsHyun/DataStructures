#ifndef _ATTACK_1_H_
#define _ATTACK_1_H_

#include "OdeloBattleSystem.h"

typedef struct Odelo_Count
{
	int Attack_Point;
	bool check_position;
}OC;
OC Black_Attack_Check[g_nMax][g_nMax];
OC White_Attack_Check[g_nMax][g_nMax];


void BlackAttack( int *x, int *y )
{
	*x = 5;
	*y = 3;
}
void BlackDefence( int x, int y )
{

}


#endif