#ifndef _ATTACK_2_H_
#define _ATTACK_2_H_


void WhiteAttack( int *x, int *y )
{
	*x = 2;
	*y = 3;
}

void WhiteDefence( int x, int y )
{

}


#endif